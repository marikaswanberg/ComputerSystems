
#./benchmark 1024 10000 >> latency_num_items.csv &&
#./benchmark 2048 10000 >> latency_num_items.csv &&
#./benchmark 4096 10000 >> latency_num_items.csv &&
#./benchmark 8192 10000 >> latency_num_items.csv &&
#./benchmark 16384 10000 >> latency_num_items.csv &&
#./benchmark 32768 10000 >> latency_num_items.csv &&
#./benchmark 65536 10000 >> latency_num_items.csv &&
#./benchmark 131072 10000 >> latency_num_items.csv &&
./benchmark 262144 10000 >> latency_num_items.csv &&
./benchmark 524288 10000 >> latency_num_items.csv &&
./benchmark 1048576 10000 >> latency_num_items.csv &&
./benchmark 2097152 10000 >> latency_num_items.csv &&
./benchmark 4194304 10000 >> latency_num_items.csv &&
./benchmark 8388608 10000 >> latency_num_items.csv &&
./benchmark 16777216 10000 >> latency_num_items.csv &&
./benchmark 33554432 10000 >> latency_num_items.csv &&
./benchmark 67108864 10000 >> latency_num_items.csv &&
./benchmark 134217728 10000 >> latency_num_items.csv &&
./benchmark 268435456 10000 >> latency_num_items.csv &&
./benchmark 536870912 10000 >> latency_num_items.csv
