
#./benchmark 1000 1024 >> sustained_throughput2.csv &&
#./benchmark 1000 2048 >> sustained_throughput2.csv &&
#./benchmark 1000 4096 >> sustained_throughput2.csv &&
#./benchmark 1000 8192 >> sustained_throughput2.csv &&
#./benchmark 1000 16384 >> sustained_throughput2.csv &&
#./benchmark 1000 32768 >> sustained_throughput2.csv &&
#./benchmark 1000 65536 >> sustained_throughput2.csv &&
#./benchmark 1000 131072 >> sustained_throughput2.csv &&
./benchmark 1000 262144 >> sustained_throughput2.csv &&
./benchmark 1000 524288 >> sustained_throughput2.csv &&
./benchmark 1000 1048576 >> sustained_throughput2.csv &&
./benchmark 1000 2097152 >> sustained_throughput2.csv &&
./benchmark 1000 4194304 >> sustained_throughput2.csv &&
./benchmark 1000 8388608 >> sustained_throughput2.csv &&
./benchmark 1000 16777216 >> sustained_throughput2.csv &&
./benchmark 1000 33554432 >> sustained_throughput2.csv &&
./benchmark 1000 67108864 >> sustained_throughput2.csv &&
./benchmark 1000 134217728 >> sustained_throughput2.csv &&
./benchmark 1000 268435456 >> sustained_throughput2.csv &&
./benchmark 1000 536870912 >> sustained_throughput2.csv
